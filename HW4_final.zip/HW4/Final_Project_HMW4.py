from tkinter import *
from tkinter.ttk import *
from tkinter import Menu
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, 
NavigationToolbar2Tk)
import pandas as pd
import datetime
from pandastable import Table
from matplotlib.widgets import SpanSelector
import matplotlib.dates as dates
import matplotlib.pyplot as plt

########################## TEST DATA ##########################


####%m-%d %H:%M:%S

plt.rcParams.update({'font.size': 7})

#global variables
series_list=[]                  #chosen time series 
data_selection_list = ['','','']   #chosen particiapant, date1, date2
chart_names = []
canvas_list = []
ogdf_list = []
#time_zone = ""
editchart_list =["","",""]
aggVar = 0
interval_list =[0,0,0,0,0,0,0]
metric_list =[0,0,0,0,0,0,0]
zoom_t = 0
#root window
window=Tk()
window.title('Homework 4')
window.geometry("1300x600")      #width,height
tabControl=Notebook(window)


def dataframeCreation(data_selection_list):
    
    #################################################### CHANGE THIS FILE PATH IF RUNNING ON OWN MACHINE ####################################################

    beg_filepath = "C:/Users/laure/Downloads/Senior year (Fall 2021 - Spring 2022)/Spring 2022/CSE 590-55 (Data Visual)/HW4/"
    file_path_values = []
    file_path_list = []

    for x in data_selection_list:
        file_path_values.append(int(x.replace('-', '')))

    while file_path_values[1] <= file_path_values[2]:
        if file_path_values[0] == 311 and (file_path_values[2] >= 20200120 or file_path_values[1] >= 20200120):  
            file_path_values[1] = 20200118
            file_path_values[2] = 20200119
        file_path_list.append(str(file_path_values[1])+"/"+str(file_path_values[0])+"/summary.csv")
        file_path_values[1] = file_path_values[1] + 1

    global temp
    temp = pd.read_csv(str(beg_filepath+file_path_list[0]))
    temp = temp.rename(columns={"Unix Timestamp (UTC)": "datetime"})


    if time_zone == "UTC":
        temp["datetime"] = temp["datetime"].apply(lambda x: datetime.datetime.fromtimestamp(int(x)/1000))
        temp = temp.set_index("datetime")

        if len(file_path_list) > 1:
            i = 1
            while i < (len(file_path_list)):
                print(file_path_list[i])
                full_path = beg_filepath+str(file_path_list[i])
                temp1 = pd.read_csv(str(full_path))
                temp1 = temp1.rename(columns={"Unix Timestamp (UTC)": "datetime"})
                temp1["datetime"] = temp1["datetime"].apply(lambda x: datetime.datetime.fromtimestamp(int(x)/1000))
                temp1 = temp1.set_index("datetime")
                temp = temp.append(temp1)
                i  = i + 1
    elif time_zone == "Local":
        
        time_offset_l = temp["Timezone (minutes)"].to_list()
        time_offset = int(time_offset_l[0])           
        temp["datetime"] = temp["datetime"].apply(lambda x: datetime.datetime.fromtimestamp((int(x)/1000)+(time_offset*60)))
        temp = temp.set_index("datetime")
    
        if len(file_path_list) > 1:
            i = 1
            while i < (len(file_path_list)):
                print(file_path_list[i])
                full_path = beg_filepath+str(file_path_list[i])
                temp1 = pd.read_csv(str(full_path))
                temp1 = temp1.rename(columns={"Unix Timestamp (UTC)": "datetime"})
                temp1["datetime"] = temp1["datetime"].apply(lambda x: datetime.datetime.fromtimestamp((int(x)/1000)+(time_offset*60)))
                temp1 = temp1.set_index("datetime")
                temp = temp.append(temp1)
                i  = i + 1
    return(temp)



def describeDF(i):
    dataframe = ogdf_list[i-1]
    describe_window = Tk()
    describe_window.geometry("800x400")
    description_frame = LabelFrame(describe_window,text="Description")
    description_frame.pack(padx=10,pady=10,fill="both", expand="yes")
    chart_frame = Frame(description_frame)
    chart_frame.pack(padx=10, pady=10,side=LEFT)
    table_frame = Frame(description_frame)
    table_frame.pack(padx=10, pady=10,side=RIGHT)
    describe_df = dataframe.describe().to_frame().reset_index()
   
    fig = Figure(figsize=(5,3),dpi = 100)
    ax = fig.add_subplot(111)
    dataframe.plot.hist(ax=ax)
    d_canvas = FigureCanvasTkAgg(fig,master=chart_frame)
    d_canvas.draw()
    d_canvas.get_tk_widget().grid(row=i,column=0)
    
    table = Table(table_frame, dataframe=describe_df)
    table.show()

def clearAgg(item,i):
    interval_list[i-1] = 0
    metric_list[i-1] = 0
    drawGraph(item,i,min_val,max_val,ogdf_list[i-1])

def intervalUpdate(item,i,canvas):
    interval = interval_variable.get()
    interval_list[i-1] = str(interval)
    localdf = temp[str(item)]
    drawGraph(item,i,min_val,max_val,localdf)

def metricUpdate(item,i,canvas):
    metric = metric_variable.get()
    metric_list[i-1] = str(metric)
    localdf = temp[str(item)]
    drawGraph(item,i,min_val,max_val,localdf)

def zoomInOut(item,i):
    print(min_val, max_val)
    zoom = zoom_variable.get()
    interval = (max_val-min_val)/4

    print(interval)
    if str(zoom) == "In":
        minv = min_val+(interval)
        maxv = max_val-(interval)
        localdf = temp[str(item)]
    elif str(zoom) == "Out":
        minv = min_val-(interval)
        maxv = max_val+(interval)
        localdf = temp[str(item)]

    drawGraph(item,i,minv,maxv,localdf)
    

def onclick(i,canvas,event,item):

    menu = Menu(canvas.get_tk_widget(),tearoff=False)
 
    aggSubMenu = Menu(menu,tearoff=False)
    intSubMenu = Menu(aggSubMenu,tearoff=False)
    metSubMenu = Menu(aggSubMenu,tearoff=False)
    zoomSubMenu = Menu(menu,tearoff=False)
    aggSubMenu.add_cascade(label="Interval", menu = intSubMenu)                                                                                                                     #drawGraph(item,i,min_val,max_val,1)
    global interval_variable
    interval_variable = StringVar()
    intSubMenu.add_checkbutton(label="1 d",variable = interval_variable, onvalue="1D", offvalue=0, command=lambda: intervalUpdate(item,i,canvas)) #'1D'     command=lambda: intervalUpdate(item,i)
    intSubMenu.add_checkbutton(label="6 h",variable = interval_variable, onvalue="6H", offvalue=0,  command=lambda: intervalUpdate(item,i,canvas)) #'6H"
    intSubMenu.add_checkbutton(label="3 h",variable = interval_variable, onvalue="3H", offvalue=0, command=lambda: intervalUpdate(item,i,canvas)) 
    intSubMenu.add_checkbutton(label="1 h",variable = interval_variable, onvalue="1H", offvalue=0, command=lambda: intervalUpdate(item,i,canvas))
    intSubMenu.add_checkbutton(label="30 min",variable = interval_variable, onvalue="30T", offvalue=0, command=lambda: intervalUpdate(item,i,canvas)) #'30T'
    intSubMenu.add_checkbutton(label="1 min",variable = interval_variable, onvalue="1T", offvalue=0, command=lambda: intervalUpdate(item,i,canvas))
    intSubMenu.add_checkbutton(label="30 s",variable = interval_variable, onvalue="30S", offvalue=0, command=lambda: intervalUpdate(item,i,canvas)) #'30S'
    aggSubMenu.add_cascade(label="Metric", menu=metSubMenu)
    global metric_variable
    metric_variable = StringVar()
    metSubMenu.add_checkbutton(label="Average", variable = metric_variable, onvalue="mean", command=lambda: metricUpdate(item,i,canvas))
    metSubMenu.add_checkbutton(label="Sum", variable = metric_variable, onvalue="sum", command=lambda: metricUpdate(item,i,canvas))
    metSubMenu.add_checkbutton(label="Min", variable = metric_variable, onvalue="min", command=lambda: metricUpdate(item,i,canvas))
    metSubMenu.add_checkbutton(label="Max", variable = metric_variable, onvalue="max", command=lambda: metricUpdate(item,i,canvas))
    aggSubMenu.add_separator()
    aggSubMenu.add_command(label="Clear",command=lambda: clearAgg(item,i))
    menu.add_cascade(label="Aggregate", menu=aggSubMenu)
    menu.add_command(label="Describe", command = lambda: describeDF(i))
    global zoom_variable 
    zoom_variable = StringVar()
    zoomSubMenu.add_checkbutton(label="Zoom In", variable = zoom_variable, onvalue = "In",command = lambda: zoomInOut(item,i)) 
    zoomSubMenu.add_checkbutton(label="Zoom Out", variable = zoom_variable, onvalue = "Out",command = lambda: zoomInOut(item,i)) 
    menu.add_cascade(label="Zoom In/Out", menu = zoomSubMenu)
    menu.add_separator()
    menu.add_command(label="Close")

    menu.tk_popup(event.x_root,event.y_root)
 

def drawGraph(item,i,min_value,max_value,df):

    if interval_list[i-1] !=0:
        if (metric_list[i-1]==0 or metric_list[i-1]=="sum"):
            df = temp[str(item)].resample(str(interval_list[i-1])).sum()
        elif metric_list[i-1] == "mean":
            df = temp[str(item)].resample(str(interval_list[i-1])).mean().bfill()
        elif metric_list[i-1] == "min":
            df = temp[str(item)].resample(str(interval_list[i-1])).min().bfill()
        elif metric_list[i-1] == "max":
            df = temp[str(item)].resample(str(interval_list[i-1])).max().bfill()

    elif interval_list[i-1] == 0:
        if metric_list  [i-1] == 0:
            df = df
        if (metric_list[i-1]=="sum"):
            df = temp[str(item)].resample("1T").sum()
        elif metric_list[i-1] == "mean":
            df = temp[str(item)].resample("1T").mean()
        elif metric_list[i-1] == "min":
            df = temp[str(item)].resample("1T").min()
        elif metric_list[i-1] == "max":
            df = temp[str(item)].resample("1T").max()                   
                                                                      
    if i == 1: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item), color='tab:blue')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas1
        canvas1 = FigureCanvasTkAgg(fig,master=tab)
        canvas1.draw()
        canvas1.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas1)
        canvas1.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas1,event,item))
    if i == 2: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:orange')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas2
        canvas2 = FigureCanvasTkAgg(fig,master=tab)
        canvas2.draw()
        canvas2.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas2)
        canvas2.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas2,event,item))
    if i == 3: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:green')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas3
        canvas3 = FigureCanvasTkAgg(fig,master=tab)
        canvas3.draw()
        canvas3.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas3)
        canvas3.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas3,event,item)) 
    if i == 4: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:red')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas4
        canvas4 = FigureCanvasTkAgg(fig,master=tab)
        canvas4.draw()
        canvas4.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas4)
        canvas4.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas4,event,item)) 
    if i == 5: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:purple')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas5
        canvas5 = FigureCanvasTkAgg(fig,master=tab)
        canvas5.draw()
        canvas5.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas5)
        canvas5.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas5,event,item))
    if i == 6: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:brown')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas6
        canvas6 = FigureCanvasTkAgg(fig,master=tab)
        canvas6.draw()
        canvas6.get_tk_widget().grid(row=i,column=0, ipady=30)
        canvas_list.append(canvas6)
        canvas6.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas6,event,item)) 
    if i == 7: 
        fig = Figure(figsize=(13,1),dpi = 100)
        plot = fig.add_subplot(111)
        plot.set_xlim([min_value,max_value])
        plot.plot(df, label = str(item),color='tab:pink')
        plot.legend(fontsize = 8,loc='upper left')
        global canvas7
        canvas7 = FigureCanvasTkAgg(fig,master=tab)
        canvas7.draw()
        canvas7.get_tk_widget().grid(row=i,column=0, ipady=30) 
        canvas_list.append(canvas7)
        canvas7.get_tk_widget().bind("<Button-3>", lambda event: onclick(i,canvas7,event,item)) 

def onselect_function(min_value, max_value):

    for i,item in enumerate(series_list,start=1):
        localdf = temp[str(item)]
        drawGraph(item,i,min_value, max_value,localdf)
    print(min_value,max_value)
    print(str(min_value),str(max_value))
    global max_val, min_val
    max_val = max_value
    min_val = min_value
    return min_value, max_value

def dataReturn(w):
 
    w.destroy()
    
    global temp
    temp = dataframeCreation(data_selection_list)

    global tab
    tab = Frame(tabControl)
    tabControl.pack(fill=BOTH,expand=True)
    tabControl.add(tab, text = str(data_selection_list[0]+"_"+str(data_selection_list[1]+"_"+str(data_selection_list[2]))))

    range_fig = Figure(figsize=(13,0.4),dpi = 100)
    range_plot = range_fig.add_subplot(111)
    range_plot.tick_params(left = False, right = False , labelleft = False ,labelbottom = False,bottom=False)
    temp.plot(y=series_list,ax=range_plot,legend=False,xlabel='')
    range_canvas = FigureCanvasTkAgg(range_fig,master=tab)
    range_canvas.draw_idle()
    range_canvas.get_tk_widget().grid(row=0,column=0)
    span = SpanSelector(range_plot,onselect_function,direction='horizontal',useblit=True,interactive=True,handle_props = {'linewidth':2,'color':'black', 'alpha': 0.5},button=1,props={'facecolor': 'grey', 'alpha': 0.3, 'fill':'True'})
    cid = range_canvas.mpl_connect('button_press_event', lambda event: span)

    #global max_val, min_val, localdf
    global ogdf_list
    min_val = range_plot.get_xlim()[0]
    max_val = range_plot.get_xlim()[1]

    for i,item in enumerate(series_list,start=1):
        ogdf_list.append(temp[str(item)])
        drawGraph(item,i,min_val,max_val,temp[str(item)])
     
        
def addtoSeries(event):
    i = lb.curselection()
    s_lb.insert('end',lb.get(i))
    series_list.append(lb.get(i))
    
def removefromSeries(event):
    item_index = s_lb.curselection()
    item_value = s_lb.get(item_index)
    s_lb.delete(item_index)
    series_list.remove(item_value)
    
def getTimeZone(event):
    value = event.widget.get()
    global time_zone
    time_zone = str(value)

def timeSeries(w):
    w.destroy()
        
    ts_window = Toplevel(window)
    ts_window.title("Import Data")
    ts_window.geometry("500x350")
    
    main_label = Label(ts_window, text="Select time series:")
    main_label.grid(row=1,column=0,sticky=W,pady=5)
    
    ###################3#######################################################333LABEL FRAMES
    ###labels
    field_label = Label(ts_window, text="Field")
    field_label.grid(row=2,column=1,sticky=S,pady=5)
    series_label = Label(ts_window, text="Series")
    series_label.grid(row=2,column=3,sticky=S,pady=5)
    time_label = Label(ts_window, text="Choose TimeZone")
    time_label.grid(row=7,column=1,rowspan=2,sticky = S, pady=20)
    
    #field listbox
    listvar = StringVar(value=["Acc magnitude avg","Eda avg","Temp avg","Movement intensity","Steps count","Rest","On Wrist"])
    global lb
    lb=Listbox(ts_window, listvariable=listvar, height=9)
    lb.grid(row=3,column=1,rowspan=3,sticky=N,pady=3)
    
    #forward/backword button
    forward_button = Button(ts_window,width=5,text=">")
    forward_button.grid(row=3,column=2,sticky=S,pady=2)
    forward_button.bind('<Button-1>',addtoSeries)
    backwards_button = Button(ts_window,width=5,text="<")
    backwards_button.grid(row=4,column=2,sticky=N,pady=2)
    backwards_button.bind('<Button-1>',removefromSeries)
    
    #Series listbox
    global s_lb
    s_listvar = StringVar(value=(series_list))
    s_lb = Listbox(ts_window,listvariable=s_listvar,height=9)
    s_lb.grid(row=3,column=3,rowspan=4,sticky=N,pady=3)    
    
    time_listvar = ("UTC", "Local")
    t_lb = Combobox(ts_window,width=20,values=time_listvar)
    t_lb.grid(row=7,column=2,columnspan = 2, rowspan=2,sticky=S,pady=20)
    t_lb.bind("<<ComboboxSelected>>", getTimeZone)
    
    #finish button
    finish_button = Button(ts_window,width=50,text="Finish",command=lambda: dataReturn(ts_window))
    finish_button.grid(row=9,column=1,columnspan=3,sticky=E,pady=30)
    
def getSubjectCBValue(event):
    value = event.widget.get()
    data_selection_list[0] = value
def getDate1CBValue(event):
    value = event.widget.get()
    data_selection_list[1] = value
def getDate2CBValue(event):
    value = event.widget.get()
    data_selection_list[2] = value
    
def importData():
    import_window = Toplevel(window)
    import_window.title("Import Data")
    import_window.geometry("400x150")
    
    main_label = Label(import_window, text="Choose data selection:")
    main_label.grid(row=1,column=0,sticky=W,pady=2)
    
    ###labels and comboboxes
    subject_label = Label(import_window, text="Subject:")
    subject_label.grid(row=4,column=0,pady=10)
    datarange_label = Label(import_window, text="Data range:")
    datarange_label.grid(row=5,column=0,pady=4)
    
    subjects=("310", "311", "312")
    subjects_cb=Combobox(import_window,width=37,values=subjects)
    subjects_cb.grid(row=4,column=1,columnspan=3,sticky=E,pady=10)
    #subjects_cd.bind("<<ComboboxSelected>>", getSubjectCBValue)
    
    dates=("2020-01-18", "2020-01-19", "2020-01-20", "2020-01-21")
    dates1_cb=Combobox(import_window,width=15,values=dates)
    dates1_cb.grid(row=5,column=1,sticky=W,pady=4)
   # dates1_cb.bind("<<ComboboxSelected>>", getDate1CBValue)
    label = Label(import_window, text="~")
    label.grid(row=5,column=2,pady=2)
    dates2_cb=Combobox(import_window,width=15,values=dates)
    dates2_cb.grid(row=5,column=3,sticky=E,pady=4)
  #  dates2_cb.bind("<<ComboboxSelected>>", getDate2CBValue)
    
    subjects_cb.bind("<<ComboboxSelected>>", getSubjectCBValue)
    dates1_cb.bind("<<ComboboxSelected>>", getDate1CBValue)
    dates2_cb.bind("<<ComboboxSelected>>", getDate2CBValue)
    
    ## next button
    next_button = Button(import_window,width=55,text="Next",command=lambda: timeSeries(import_window))
    next_button.grid(row=10,column=0,columnspan=4,sticky=E,pady=20)

def getAggResults(event):
    value = event.widget.get()
    editchart_list[2] = str(value)
    #f = temp[str(item)].resample(str(interval_list[i-1])).sum()
def getChart(event):
    value = event.widget.get()
    editchart_list[0] = str(value)
def getChartType(event,window):
    value = event.widget.get()
    editchart_list[1] = str(value)

    if value == "Bar":
        group_label = Label(window, text="Aggregate By:")
        group_label.grid(row=6,column=0,pady=4)
        group = ["1D","6H","3H","1H","30M","30S"]
        group_cb=Combobox(window,width=37,values=group)
        group_cb.grid(row=6,column=1,columnspan=3,sticky=E,pady=10)
        group_cb.bind("<<ComboboxSelected>>", getAggResults)


def editChartResults(window):
    index = series_list.index(editchart_list[0])
    canvas = canvas_list[index+1]

    df = temp[str(editchart_list[0])]
    fig = Figure(figsize=(13,1),dpi = 100)
    plot = fig.add_subplot(111)
    x1 = dates.num2date(min_val)
    x1 = x1.strftime("%Y-%m-%d %H:%M:%S")
    x2 = dates.num2date(max_val)
    x2 = x2.strftime("%Y-%m-%d %H:%M:%S")

    print(x1,x2)
    print(editchart_list)
    if str(editchart_list[1]) == "Bar":
        new = df.resample(str(editchart_list[2])).sum()
        new.plot.bar(ax = plot, rot=0)
        if str(editchart_list[2]) == "6H":
            for i, t in enumerate(plot.get_xticklabels()):
                if (i % 6) != 0:
                    t.set_visible(False)
        for container in plot.containers:
            plot.bar_label(container, label_type = 'center')
        
        #plot.set_xlim([x1,x2])
        #new.plot(kind='bar',ax=plot)
    elif str(editchart_list[1]) == "Histogram":
        df.hist(ax = plot, rot = 0)
    elif str(editchart_list[1]) == "Line":
        plot.plot(df)

    #df.plot(ax=plot, kind=str(editchart_list[1]))
    canvas = FigureCanvasTkAgg(fig,master=tab)
    canvas.draw()
    canvas.get_tk_widget().grid(row=(index+1),column=0, ipady=30)
    canvas.get_tk_widget().bind("<Button-3>", lambda event: onclick(index+1,canvas1,event,editchart_list[0]))    

    

def editData():
    edit_window = Toplevel(window)
    edit_window.title("Edit Chart Type")
    edit_window.geometry("450x300")
    
    main_label = Label(edit_window, text="Choose data chart to change:")
    main_label.grid(row=1,column=0,sticky=W,pady=2)
    
    ###labels and comboboxes
    data_label = Label(edit_window, text="Data:")
    data_label.grid(row=4,column=0,pady=10)
    chart_type_label = Label(edit_window, text="Chart Type:")
    chart_type_label.grid(row=5,column=0,pady=4)
    
    data_label = series_list
    data_cb=Combobox(edit_window,width=37,values=data_label)
    data_cb.grid(row=4,column=1,columnspan=3,sticky=E,pady=10)

    chart_type = ["Bar", "Histogram", "Scatter", "Line"]
    chart_type_cb=Combobox(edit_window,width=37,values=chart_type)
    chart_type_cb.grid(row=5,column=1,columnspan=3,sticky=E,pady=10)

    data_cb.bind("<<ComboboxSelected>>", getChart)
    chart_type_cb.bind("<<ComboboxSelected>>", lambda event: getChartType(event, edit_window))

    next_button = Button(edit_window,width=55,text="Next",command=lambda: editChartResults(edit_window))
    next_button.grid(row=10,column=0,columnspan=4,sticky=E,pady=20)

################## MENU #################
menubar = Menu(window)

#Data Menu
data = Menu(menubar, tearoff = 0)
data.add_command(label='Import Data', command = importData)
data.add_separator()
data.add_command(label = 'Exit', command = window.destroy)
menubar.add_cascade(label='Data', menu=data)

#Edit Menu
edit = Menu(menubar, tearoff = 0)
edit.add_command(label="Edit Chart Type", command=editData)
menubar.add_cascade(label='Edit', menu=edit)

#Time series Menu
timeseries = Menu(menubar, tearoff = 0)
timeseries.add_command(label="Time series")
menubar.add_cascade(label='Time series', menu=timeseries)

#analysis menu
analysis = Menu(menubar, tearoff = 0)
analysis.add_command(label="Analysis")
menubar.add_cascade(label='Analysis', menu=analysis)

window.config(menu=menubar)
################## MENU #################

mainloop()